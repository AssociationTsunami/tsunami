# TODO LIST

1. Add jPlayer with a playlist on id="bottom" side of the cube.
2. Get images for each musician/artist and fix the the display so that when a user clicks on the menu image, the background image changes and we add a info box about the musician/artist with links to their website and contact details
3. figure out how to implement the paypal button so that people can pre-book and purchase tickets in advance.
4. in the future it maybe good to provide members ability to login and upload their own content.
5. Add jPlayer on the 'Les Artistes' cube side, so that when a user clicks on a image, the background image changes and a smaller version of the jPlayer button is loaded which has a playlist of all the artist's related audio (perhaps see if i can implement a video) content. 

#FIXME

* FireFox - DONE

The cube is broken, use https://developer.mozilla.org/en-US/docs/CSS/user-select so that each side of the cube is like:

    |////////////////////|
    |//                //|
    |//                //|
    |//                //|
    |//                //|
    |//                //|
    |//                //|
    |////////////////////|

where the '//' area is selectable and draggable but the white area is non user selectable.

Test to see if this works with jquery-ui tabs and accordion. - DONE


